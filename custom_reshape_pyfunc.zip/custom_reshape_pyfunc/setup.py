from setuptools import setup

VERSION='0.1'
setup(name='custom_reshape_pyfunc',
      version=VERSION,
      description='just sample only',
      url='https://github.ibm.com/NGP-TWC/wml-online-scoring-py/',
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=[
            'cust_py_func'
      ],
      zip_safe=False)
