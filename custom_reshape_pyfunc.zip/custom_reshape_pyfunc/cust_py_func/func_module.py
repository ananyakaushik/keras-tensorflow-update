import tensorflow as tf
import numpy as np
from tensorflow.python.framework import ops
tf.enable_eager_execution()

def reshape_func(x):
    return tf.reshape(x, [-1, 28, 28, 1]) 

def reshape_grad(op, grad):
    x = op.inputs[0]

    return grad

def create_py_func_with_grads(op, inp, tout, name=None, grad=None):
    grad_name = 'PyFuncGrad' + str(np.random.randint(0, 1e+8))

    tf.RegisterGradient(grad_name)(grad)
    g = tf.get_default_graph()

    with g.gradient_override_map({"PyFunc": grad_name}):
        return tf.py_function(op, inp, tout, name=name)

def initialize_py_func(g=None):
    #x = tf.placeholder(name='x', shape=(None, 784), dtype=tf.float32)
    (x_train, y_train), _ = tf.keras.datasets.mnist.load_data()
    x_train = tf.convert_to_tensor(x_train)
    return create_py_func_with_grads(reshape_func, [x_train], tf.uint8, name='ReshapeFunc', grad=reshape_grad)
